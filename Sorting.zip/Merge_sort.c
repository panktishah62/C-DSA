#include <stdio.h>
#include <stdlib.h>

int main(){
int n,i,j,temp,min,loc;
printf("no. of elements in array\n");
scanf("%d",&n);
int arr[n];

printf("enter %d elements of list 1\n",n);
for(i=0;i<n;i++){
    scanf("%d",&arr[i]);
}

